package traditional;

import lombok.ToString;
import traditional.Coffe;

@ToString
public class Cup {

    private Liquid liquid;
    private Coffe coffe;

    public Cup(Liquid liquid) {
        this.liquid = liquid;
    }

    public Cup(Coffe coffe) {
        this.coffe = coffe;
    }

    void drink() {
        System.out.println("Drinking " + liquid);
    }
}
