package withGenerics;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class Liquid {
    private double desnsiteti;
    private double vellimi;
}
