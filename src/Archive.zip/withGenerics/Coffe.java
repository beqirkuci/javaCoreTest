package withGenerics;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class Coffe {
    private String ngjyra;
    private String origjina;
}
